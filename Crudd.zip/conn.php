<?php
$host = "localhost";
$user = "root";
$pass = "";
$db = "my_crud";

$con = mysqli_connect($host,$user,$pass,$db);

if($con) {
    echo "CRUD:";
} else {
    echo "Not Connected";
}

?>